
export default function Optimizer() {
  return (
    <div style={{ backgroundColor: '#0b0c10', color: '#66fcf1', fontFamily: 'Arial', padding: '2rem' }}>
      <h1>DFS Optimizer (Coming Soon)</h1>
      <p>This is where your lineup builder will live.</p>
    </div>
  );
}
